sap.ui.define([], function() {
	"use strict";
	return {

		paymentStatus: function(val) {
			var statusDescription = "";
			var paymentData = sap.ui.getCore().getModel("PymntGlobalModel").getData();
			paymentData.results.forEach(function(value, idx) {
				if (value.AMD_PAY_STATUS === val) {
					statusDescription = value.desc;
				}
			});
			return statusDescription;
		},

		TicketPriority: function(val) {
			var Description = "";
			var TicketPData = sap.ui.getCore().getModel("TicketPriorityGlobModel").getData();
			TicketPData.results.forEach(function(value, idx) {
				if (value.Priority === val) {
					Description = value.Desc;
				}
			});
			return Description;
		},
		serviceType: function(val) {
			var serviceTypeDes = "";
			var paymentData = sap.ui.getCore().getModel("ServiceStatGlobalModel").getData();
			paymentData.results.forEach(function(value, idx) {
				if (value.SERIVETYPE === val) {
					serviceTypeDes = value.Desc;
				}
			});
			return serviceTypeDes;
		},
		
		getControlStatusDesc: function(val) {
			var ControlStatDes = "";
			var ControlStatData = sap.ui.getCore().getModel("ControlStatus").getData();
		ControlStatData.results.forEach(function(value, idx) {
				if (value.ContStat === val) {
					ControlStatDes = value.Desc;
				}
			});
			return ControlStatDes;
		},

		serviceGl: function(val) {
			var serviceGlDes = "";
			var paymentData = sap.ui.getCore().getModel("ServiceGlGlobalModel").getData();
			paymentData.results.forEach(function(value, idx) {
				if (value.Service_gl === val) {
					serviceGlDes = value.Desc;
				}
			});
			return serviceGlDes;
		},

		getSAResName: function(val) {
			var SAResName = "";
			var SAResData = sap.ui.getCore().getModel("SAResGlobModel").getData();
			SAResData.results.forEach(function(value, idx) {
				if (value.SA_RESOURCE === val) {
					SAResName = value.SA_RESOURCE_Name;
				}
			});
			return SAResName;
		},
		getAMSResName: function(val) {
			var AMSResName = "";
			var AMSResData = sap.ui.getCore().getModel("AMSResGlobModel").getData();
			AMSResData.results.forEach(function(value, idx) {
				if (value.AMS_RESOURCE === val) {
					AMSResName = value.Name;
				}
			});
			return AMSResName;
		},

		formatDate: function(value) {
			var abc = value;
		},
		getStatus: function(val) {
			var Description = "";
			if (sap.ui.getCore().getModel("StatusGlobModel")) {
				var StatData = sap.ui.getCore().getModel("StatusGlobModel").getData();
				StatData.results.forEach(function(value, idx) {
					if (value.HStatus === val) {
						Description = value.StatusDesc;
					}
				});
			}
			return Description;
		},
		MngrApprvStatus: function(val) {
			var Description = "";
			var MngrStatData = sap.ui.getCore().getModel("MngrGlobStatModel").getData();
			MngrStatData.results.forEach(function(value, idx) {
				if (value.Manappstat === val) {
					Description = value.appstat_desc;
				}
			});
			return Description;
		},
		dateTime: function(d) {
			var o = (d instanceof Date) ? d : new Date(d);
			var a = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd.MM.yyyy HH:mm"
			});
			return a.format(o);
		},

		getEditable: function(val) {
			var Editable = false;
			if (val !== "CO") {
				Editable = true;
			}
			return Editable;
		}
	};
});