/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"AMSMONITOR/ZAMSMONITOR_PAYMENTUPDATE/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});